<?php include('partials/_header.php') ?>

<!-- confirm edit alert modal-->
<div class="modal fade" id="edit-confirmation-modal" tabindex="-1" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog  modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
            </div>
            <div class="modal-body">
                <strong>Та үнэхээр багшийн мэдээллийг засварлахыг хүсч байна уу?</strong>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Хаах</button>
                <button type="button" class="btn btn-danger" id="confirm-edit-btn">Засварлах</button>
            </div>
        </div>
    </div>
</div>
<!-- end of onfirm edit alert modal-->

<!-- alert to delete teacher  -->
<div class="modal fade" id="delete-confirmation-modal" tabindex="-1" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog  modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
            </div>
            <div class="modal-body">
                <strong>Та үнэхээр Багшийг устгахыг хүсч байна уу?</strong>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Хаах</button>
                <button type="button" class="btn btn-danger" onclick="deleteTeacherWithIdSeted()">Устгах</button>
            </div>
        </div>
    </div>
</div>
<!-- end of alert to delete teacher -->
<!--add new student model -->


<div class="modal" style="z-index: 2000;" id="addTeacherModal" tabindex="-1" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title fs-5" id="exampleModalLabel">Багшийн дэлгэрэнгүй мэдээлэл</h1>
                <button type="button" class="close mr-2" data-bs-dismiss="modal" aria-label="Close"><i
                        class='bx bx-x'></i></button>
            </div>
            <form class="needs-validation" id="general-form" novalidate>
                <div class="modal-body">
                    <div class="container my-3">
                        <div class="mb-3">
                            <label for="fullname" class="form-label">Бүтэн нэр</label>
                            <div class="row">
                                <div class="col">
                                    <input type="text" class="form-control" placeholder="Нэр"
                                        aria-label="First name" id="fname" name="fname" required>
                                    <div class="invalid-feedback">
                                    шаардлагатай!
                                    </div>
                                </div>
                                <div class="col">
                                    <input type="text" class="form-control" placeholder="Овог нэр"
                                        aria-label="Last name" id="lname" name="lname" required>
                                    <div class="invalid-feedback">
                                    шаардлагатай!
                                    </div>
                                </div>
                            </div>
                        </div>



                        <div class="mb-3">
                        <label for="details" class="form-label">Дааж авсан анги</label>
                        <div class="row">
                                <div class="col">
                                <select class="form-select" id="class" name="class" style="width:100%;" required>

                                    <option selected disabled value="">---сонгох--</option>                                   
                                    <!-- <option value="12s">12 (Math)</option>
                                    <option value="12s">12 (Bio)</option>
                                    <option value="12c">12 (Commerce)</option>
                                    <option value="11s">11 (Math)</option>
                                    <option value="11s">11 (Bio)</option>
                                    <option value="11c">11 (Commerce)</option>
                                    <option value="10">10</option>
                                    <option value="9">9</option>
                                    <option value="8">8</option>
                                    <option value="7">7</option>
                                    <option value="6">6</option>
                                    <option value="5">5</option>
                                    <option value="4">4</option>
                                    <option value="3">3</option>
                                    <option value="2">2</option>
                                    <option value="1">1</option>
                                    <option value="pg">pg</option>
                                    <option value="lkg">lkg</option>
                                    <option value="ukg">ukg</option> -->
                                    <option value="pg">хоосон</option>
                                    <?php include('partials/select_classes.php') ?>
                                    </select>
                                    <div class="invalid-feedback">
                                    шаардлагатай!
                                    </div>
                                </div>
                                <div class="col">
                                <select class="form-select" id="section" name="section" style="width:100%;"
                                        required>
                                        <option selected disabled value="">--сонгох--</option>
                                        <option value="C">хоосон</option>
                                        <option value="A">A</option>
                                        <option value="B">Б</option>
                                        <option value="C">В</option>
                                        <option value="C">Г</option>
                                        <option value="C">Д</option>
                                    </select>
                                    <div class="invalid-feedback">
                                    шаардлагатай!
                                    </div>
                                </div>
                            </div>
                            <div class="invalid-feedback" id="invaldClassteacher">
                            Аль аль нь тохирохгүй эсвэл хоёуланг нь сонгосон!!
                                    </div>
                        </div>

                        <div class="mb-3">
                            <label for="subject" class="form-label">Холбоотой сэдэв</label>
                            <input type="text" class="form-control" id="subject" aria-describedby="emailHelp"
                                name="subject" required>
                            <div class="invalid-feedback">
                            шаардлагатай!
                            </div>
                        </div>

                        <div class="mb-3">
                            <label for="gender" class="form-label">Хүйс</label>
                            <select class="form-select" id="gender" name="gender" required>
                                <option selected disabled value="">--сонгох--</option>
                                <option value="Male">Эрэгтэй</option>
                                <option value="Female">Эмэгтэй</option>
                            </select>
                            <div class="invalid-feedback">
                            шаардлагатай!
                            </div>
                        </div>

                        <div class="mb-3">
                            <label for="dob" class="form-label">Төрсөн огнооtest</label>
                            <input type="date" class="form-control" id="dob" aria-describedby="emailHelp" name="dob"
                                required>
                            <div class="invalid-feedback">
                            шаардлагатай!
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">

                    <button type="button" class="btn btn-primary" id="general-info-btn">
                        <div><i class='bx bxs-chevrons-right'></i><span> дараагийн</span></div>
                    </button>
                </div>
            </form>

        </div>
    </div>
</div>

<!-- personal information -->
<div class="modal" style="z-index: 2000;" id="personalInformationModal" tabindex="-1"
    aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title fs-5" id="exampleModalLabel">Хаягийн дэлгэрэнгүй мэдээлэл</h1>
                <button type="button" class="close mr-2" data-bs-dismiss="modal" aria-label="Close"><i
                        class='bx bx-x'></i></button>
            </div>
            <form class="needs-validation" id="personal-form" novalidate>
                <div class="modal-body">
                    <div class="container my-3">

                        <div class="mb-3">
                            <label for="phone" class="form-label">Утасны дугаар</label>
                            <input type="tel" class="form-control" id="phone" name="phone"
                                placeholder="Утасны дугаар оруулна уу" required>
                            <div class="valid-feedback">
                                <!-- Bootstrap "check" icon for valid input -->
                                <!-- <i class="bi bi-check text-success"></i> -->
                            </div>
                            <div class="invalid-feedback" id="phone-mdg">
                            Хүчинтэй 8 оронтой утасны дугаар оруулна уу.
                            </div>
                        </div>

                        <div class="mb-3">
                            <label for="email" class="form-label">Имэйл</label>
                            <input type="email" class="form-control" id="email" aria-describedby="emailHelp"
                                name="email" required>
                            <div class="invalid-feedback">
                            шаардлагатай!
                            </div>
                        </div>

                        <div class="mb-3">
                            <label for="address" class="form-label">Хаяг</label>
                            <input type="text" class="form-control" id="address" aria-describedby="emailHelp"
                                name="address" required>
                            <div class="invalid-feedback">
                            шаардлагатай!
                            </div>
                        </div>


                        <div class="mb-3">
                            <label for="exampleInputEmail1" class="form-label">Хот</label>
                            <div class="row">
                                <div class="col">
                                    <input type="text" class="form-control" id="city" placeholder="Хотын нэр"
                                        aria-label="First name" name="city" required>
                                    <div class="invalid-feedback">
                                    шаардлагатай!
                                    </div>
                                </div>
                                <div class="col">
                                    <input type="text" class="form-control" id="zip" placeholder="Zip code"
                                        aria-label="Last name" name="zip" required>
                                    <div class="invalid-feedback">
                                    шаардлагатай!
                                    </div>
                                </div>
                            </div>
                        </div>


                        <div class="mb-3">
                            <label for="state" class="form-label">Дүүрэг</label>
                            <select class="form-select" aria-label="Default select example" id="state" name="state"
                                required>
                                <option selected disabled value="">--сонгох--</option>
                                <option value="Hariyana">Хан-Уул</option>
                                <option value="UP">Чингэлтэй</option>
                                <option value="Delhi">Сонгинхайрхан</option>
                                <option value="Panjab">Баянзүрх</option>
                                <option value="Gujrat">Сүхбаатар</option>
                                <option value="Gujrat">Налайх</option>
                                <option value="Gujrat">Баянгол</option>
                                <option value="Gujrat">Багануур</option>
                                <option value="Gujrat">Багахангай</option>
                            </select>
                            <div class="invalid-feedback">
                            шаардлагатай!
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                   <button type="button" onclick="backToStudentDetail()" class="btn btn-secondary">
                        <div><i class='bx bxs-chevrons-left'></i><span>Буцах</span></div>
                    </button>
                    <button type="button" class="btn btn-primary" id="personal-info-btn">
                        <div><i class='bx bxs-chevrons-right'></i><span> дараагийн</span></div>
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
<!-- end of personal information-->

<!-- Guardian information -->
<div class="modal" style="z-index: 2000;" id="guardian_information" tabindex="-1" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title fs-5" id="exampleModalLabel">Яаралтай тусламжийн холбоо барих мэдээлэл</h1>
                <button type="button" class="close mr-2" data-bs-dismiss="modal" aria-label="Close"><i
                        class='bx bx-x'></i></button>
            </div>
            <form class="needs-validation" id="guradian-form" novalidate>
                <div class="modal-body">

                    <div class="container my-3">
                        <div class="mb-3">
                            <label for="guardian" class="form-label">Нэр</label>
                            <input type="text" class="form-control" id="guardian" aria-describedby="emailHelp"
                                name="guardian" required>
                            <div class="invalid-feedback">
                            шаардлагатай!
                            </div>
                        </div>

                        <div class="mb-3">
                            <label for="gphone" class="form-label">Утасны дугаар</label>
                            <input type="tel" class="form-control" id="gphone" name="gphone"
                                placeholder="Утасны дугаар оруулна уу" required>
                            <div class="valid-feedback">
                            </div>
                            <div class="invalid-feedback" id="phone-g">
                            Хүчинтэй 8 оронтой утасны дугаар оруулна уу.
                            </div>
                        </div>

                        <div class="mb-3">
                            <label for="gaddress" class="form-label">Хаяг</label>
                            <input type="text" class="form-control" id="gaddress" aria-describedby="emailHelp"
                                name="gaddress" required>
                            <div class="invalid-feedback">
                            шаардлагатай!
                            </div>
                        </div>

                        <div class="mb-3">
                            <label for="city-info" class="form-label">Хот</label>
                            <div class="row">
                                <div class="col">
                                    <input type="text" class="form-control" placeholder="Хотын нэр"
                                        aria-label="First name" id="gcity" name="gcity" required>
                                    <div class="invalid-feedback">
                                    шаардлагатай!
                                    </div>
                                </div>
                                <div class="col">
                                    <input type="text" class="form-control" placeholder="Zip code"
                                        aria-label="Last name" id="gzip" name="gzip" requireds>
                                    <div class="invalid-feedback">
                                    шаардлагатай!
                                    </div>
                                </div>
                            </div>
                        </div>


                        <div class="mb-3">
                            <label for="relation" class="form-label">Хэн болох</label>
                            <input type="text" class="form-control" id="relation" aria-describedby="emailHelp"
                                name="relation" required>
                            <div class="invalid-feedback">
                            шаардлагатай!
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                   <button type="button" class="btn btn-secondary" onclick="backToAddressDetail()">
                        <div><i class='bx bxs-chevrons-left'></i><span>Буцах</span></div>
                    </button>
                    <button type="button" class="btn btn-primary" id="guardian-form-btn"><span>Илгээх</span></button>
                </div>
            </form>
        </div>
    </div>
</div>
<!-- end of Guardian information-->


<!-- end of add new student model -->

<!-- Remove student model -->
<div class="modal removeTeacherModal" style="z-index: 2000;" id="removeStudentModel" tabindex="-1"
    aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title text-danger fs-5" id="exampleModalLabel">Багшийг устгах</h1>
                <button type="button" class="close mr-2" data-bs-dismiss="modal" aria-label="Close"><i
                        class='bx bx-x'></i></button>
            </div>
            <form class="needs-validation" id="remove-teacher-form" novalidate>
                <div class="modal-body">
                    <div class="container my-3">

                        <div class="mb-3">
                            <label for="teacher-id" class="form-label"> Багшийн ID</label>
                            <input type="text" class="form-control" id="teacher-id" aria-describedby="" required>
                            <div class="invalid-feedback">
                            Багшийн үнэмлэхийг хүчинтэй өгнө үү.
                            </div>
                        </div>


                    </div>
                </div>
                <div class="modal-footer">

                    <button type="button" class="btn btn-danger" id="remove-teacher-btn">
                        <div><span>Багшийг устгах</span></div>
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- end of Remove student model -->

<!-- Sidebar -->
<?php include('partials/_sidebar.php') ?>
<input type="hidden" value="2" id="checkFileName">
<!-- End of Sidebar -->

<!-- Main Content -->
<div class="content">
    <!-- Navbar -->
    <?php include("partials/_navbar.php"); ?>

    <!-- End of Navbar -->

    <main>
        <div class="header">
            <div class="left">
                <h1>Багш</h1>

            </div>

        </div>
        <div class="bottom-data">

            <div class="orders">

                <!-- Nav tabs -->
                <ul class="nav nav-tabs" id="myTab" role="tablist">
                    <li class="nav-item me-1" role="presentation">
                        <button class="nav-link active " id="addTeacherTab" data-bs-toggle="tab" data-bs-target="#home"
                            type="button" role="tab" aria-controls="home" aria-selected="true">Багш нэмэх</button>
                    </li>
                    <li class="nav-item me-1" role="presentation">
                        <button class="nav-link" id="showTeacherTab" data-bs-toggle="tab" data-bs-target="#profile"
                            type="button" role="tab" aria-controls="profile" aria-selected="false"
                            onclick="showTeachers()">Багш нарыг үзүүлэх
                            </button>
                    </li>
                    
                    
                    <li class="nav-item me-1" role="presentation">
                        <button class="nav-link" id="show-leave-tab" data-bs-toggle="tab" data-bs-target="#leave-tab"
                            type="button" role="tab" aria-controls="leave-tab" aria-selected="false"
                          >Гарсан багш</button>
                    </li>

                </ul>

                <!-- Tab panes -->
                <div class="tab-content">
                    <div class="tab-pane active" id="home" role="tabpanel" aria-labelledby="home-tab" tabindex="0">
                        <br>
                        <!-- Take attendence -->
                        <div class="attendenceTable" style="display: block;">
                            <div class="header">
                                <i class='bx bx-receipt'></i>
                                <h3>Багш нар</h3>
                                <div class="student-btns">
                                    <div class="student-btns">

                                        <div class="dropdown dropdown-center">
                                            <a class="notif" data-bs-toggle="dropdown" aria-expanded="false"
                                                id="dropDownListForSubmit">
                                                <i class='bx bx-filter'></i>
                                            </a>

                                            <ul class="dropdown-menu">
                                                <li><a class="dropdown-item reset-attendence" id="add_student_dropdown"
                                                        data-bs-toggle="modal" data-bs-target="#addTeacherModal">Багшийг нэмэх
                                                        </a></li>
                                                <li><a class="dropdown-item submit-attendence"
                                                        id="remove_student_dropdown" data-bs-toggle="modal"
                                                        data-bs-target="#removeStudentModel">Багшийг устгах</a></li>
                                            </ul>
                                        </div>

                                    </div>
                                </div>
                            </div>
                            <hr>
                            <br>

                            <div class="container add-remove">
                                <ul class="insights">
                                    <a class="addlink" data-bs-toggle="modal" data-bs-target="#addTeacherModal"
                                        id="addTeacherButton">
                                        <li class="additem">
                                            <!-- <i class='bx bx-calendar-check'></i> -->
                                            <i class='bx bxs-user-plus'></i>
                                            <span class="info">
                                                <h3>
                                                Багш
                                                </h3>
                                                <h3>Нэмэх</h3>
                                            </span>
                                        </li>
                                    </a>
                                    <!-- model add student -->





                                    <!-- end of model add student -->

                                    <a class="removelink" data-bs-toggle="modal" data-bs-target="#removeStudentModel">
                                        <li class="removeitem">
                                            <i class='bx bxs-user-minus'></i>
                                            <span class="info">
                                                <h3>
                                                Багш
                                                </h3>
                                                <h3>Хасах</h3>
                                            </span>
                                        </li>
                                    </a>
                                </ul>
                            </div>

                            <br>
                            <hr>
                        </div>

                        <!-- end of Take attendence -->
                    </div>
                    <br>
                    <div class="tab-pane" id="profile" role="tabpanel" aria-labelledby="profile-tab" tabindex="0">
                        <div class="showAttendence">
                           
                            <!-- Attendence on Specific date  -->
                            <div class="container">
                                <br>
                                <!-- Take attendence -->
                                <div class="attendenceTable" style="display: block;">
                                    <div class="header">
                                        <i class='bx bx-list-ul'></i>
                                        <h3>Багш нарын жагсаалт</h3>

                                        <!-- <a href="#" class="excel">
                                            <i class="fa fa-file-excel-o" aria-hidden="true"></i>
                                            <span>EXCEL</span>
                                        </a>

                                        <a href="#" class="report">
                                            <i class='bx bxs-file-pdf'></i>
                                            <span>PDF</span>
                                        </a> -->

                                        <div class="_flex-container">
                                        <input class="form-control me-2" type="search" placeholder="Search" style="max-width: 225px;height: 40px;" id="search-teacher-name"
                                            aria-label="Search">
                                        <button class="btn btn-success" type="button" id="searchTeacherByNameBtn" disabled><i class='bx bx-search-alt'></i></button>
                                    </div>

                                    </div>
                                    <hr class="text-danger">
                                    <!--table-->
                                    <div class="students-table">
                                        <table class="remove-cursor-pointer">
                                            <thead>
                                                <tr>
                                                    <th scope="col" class="thead col-2">#</th>
                                                    <th scope="col" class="thead col-2">ID</th>
                                                    <th scope="col" class="thead col-5">Нэр</th>
                                                    <th scope="col" class="thead col-3">Мэргэжил</th>
                                                </tr>
                                            </thead>

                                            <tbody id="teacher-table-body">
                                                <!-- content come form database -->
                                            </tbody>

                                        </table>
                                    </div>
                                    <div id="dataNotAvailable">

                                        <div class="_flex-container box-hide">

                                            <div class="no-data-box">
                                                <div class="no-dataicon">
                                                    <i class='bx bx-data'></i>
                                                </div>
                                                <p>Өгөгдөл байхгүй</p>
                                            </div>
                                        </div>

                                    </div>
                                    <!--END table-->
                                </div>
                                <hr class="text-danger">

                                <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                                    <div class="btn-group" role="group" aria-label="Basic example">
                                        <button type="button" class="btn btn-secondary" id="prev-page-btn">өмнөх</button>
                                        <a class="btn btn-secondary disabled" role="button" aria-disabled="true"
                                            id="page-number">1</a>
                                        <button type="button" class="btn btn-secondary" id="next-page-btn">дараагийн</button>
                                    </div>
                                </div>


                            </div>
                            <!-- Attendence on Specific date  -->

                        </div>
                    </div>

                    <div class="tab-pane" id="leave-tab" role="tabpanel" aria-labelledby="leave-tab" tabindex="0">
                       <?php include('partials/teacher-shared/teachers-leave-tab.php') ?>
                   </div>


                </div>

            </div>


        </div>

    </main>


</div>


<script src="../assets/js/teacher.js"></script>
<script src="../assets/js/teacher-leave-on-admin.js"></script>
<?php include('partials/_footer.php'); ?>